

//import '.env/config';
import { test } from '@playwright/test';

import { loginPage } from '../../pages/loginPage';

const TEST_EMAIL = process.env.TEST_EMAIL?.trim();
const TEST_PASSWORD = process.env.TEST_PASSWORD?.trim();

const credentialsMissing = !TEST_EMAIL || !TEST_PASSWORD;

test.describe('Kapruka Login Test', () => {
  

    test('Valid user should login successfully', async ({ page }) => {
        const loginPage1 = new loginPage(page);
        await loginPage1.goto();
        await loginPage1.isLoaded();
        await loginPage1.login(TEST_EMAIL as string, TEST_PASSWORD as string);
        await loginPage1.verifyLoginSuccess();
    });
});
